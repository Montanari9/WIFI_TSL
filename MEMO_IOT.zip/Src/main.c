/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"
#include "tim.h"
#include "tsc.h"
#include "usart.h"
#include "gpio.h"

/* USER CODE BEGIN Includes */
#include "define.h"
#include "tsl.h"

#define WIFI 1
#ifdef WIFI
#include "wifi_interface.h"
#include "stdio.h"
#include "string.h"
#include "wifi_globals.h"
#endif
    
#define TSL_USE 1
#ifdef TSL_USE
unsigned int  KeyRead;
uint16_t TouchRef[4];
uint32_t TouchRefSum[4];
#endif
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
#define TEST_TKEY(NB)   (MyTKeys[(NB)].p_Data->StateId == TSL_STATEID_DETECT)
#define LINEAR_DETECT ((MyLinRots[0].p_Data->StateId == TSL_STATEID_DETECT) || \
                       (MyLinRots[0].p_Data->StateId == TSL_STATEID_DEB_RELEASE_DETECT))
#define LINEAR_POSITION (MyLinRots[0].p_Data->Position)

extern CONST TSL_Bank_T MyBanks[];
extern TSL_Zone_T MyZone;
extern CONST TSL_TouchKey_T MyTKeys[];
extern CONST TSL_LinRot_T MyLinRots[];
extern CONST TSL_Object_T MyObjects[];
extern TSL_ObjectGroup_T MyObjGroup;

void TSL_user_Init(void);
TSL_Status_enum_T TSL_user_Action(void);
void TSL_user_SetThresholds(void);

unsigned char BYPASS_DTO;
unsigned char ENABLE_RESET_BYPASS_DTO;

/* Private variables ---------------------------------------------------------*/

// For debug purpose with STMStudio
uint8_t DS[TSLPRM_TOTAL_TKEYS + TSLPRM_TOTAL_LNRTS]; // To store the States (one per object)
int16_t DD[TSLPRM_TOTAL_TKEYS + (TSLPRM_TOTAL_LNRTS * 3)]; // To store the Deltas (one per channel)
#ifdef WIFI
wifi_state_t wifi_state;
wifi_config config;
uint8_t console_input[1], console_count=0;
char console_ssid[40];
wifi_bool set_AP_config = WIFI_FALSE;

char * ssid = "Bruno";
char * seckey = "123456789";
uint8_t channel_num = 6;
WiFi_Priv_Mode mode = WPA_Personal;     
char echo[512];
uint16_t len;

char server_write[16];
uint16_t len_write;
#endif

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void Error_Handler(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void ProcessSensors(void);

#ifdef WIFI
WiFi_Status_t wifi_get_AP_settings(void);
extern UART_HandleTypeDef UartHandle,UartMsgHandle;
char print_msg_buff[512];
#endif

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */
#ifdef WIFI
  WiFi_Status_t status = WiFi_MODULE_SUCCESS;
#endif  
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM17_Init();
  MX_TSC_Init();
  MX_USART1_UART_Init();

  /* USER CODE BEGIN 2 */
  
#ifdef WIFI
  /* configure the timers  */
  Timer_Config();
  
  UART_Configuration(115200); 
#ifdef USART_PRINT_MSG
  UART_Msg_Gpio_Init();
  USART_PRINT_MSG_Configuration(115200);
#endif  
  
  config.power=wifi_active;
  config.power_level=high;
  config.dhcp=on;//use DHCP IP address
  
  wifi_state = wifi_state_idle;
  
  status = wifi_get_AP_settings();
  if(status!=WiFi_MODULE_SUCCESS)
  {
    printf("\r\nError in AP Settings");
    return 0;
  }
  
  printf("\r\n\nInitializing the wifi module...");
  
  /* Init the wi-fi module */  
  status = wifi_init(&config);
  if(status!=WiFi_MODULE_SUCCESS)
  {
    printf("Error in Config");
    while(1);
  }
#endif
  

  
  //============================================================================
  // Init STMTouch driver
  //============================================================================  
  
  TSL_user_Init();
  
  //============================================================================
  // Main loop
  //============================================================================
  
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    
    // Execute STMTouch Driver state machine
    if( TSL_user_Action() == TSL_STATUS_OK ){
      ProcessSensors(); // Execute sensors related tasks
    }   
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI48;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* USER CODE BEGIN 4 */
#ifdef WIFI


/**
* @brief  Query the User for SSID, password and encryption mode
* @param  None
* @retval WiFi_Status_t
*/
WiFi_Status_t wifi_get_AP_settings(void)
{
  WiFi_Status_t status = WiFi_MODULE_SUCCESS;
  printf("\r\n\n/********************************************************\n");
  printf("\r *                                                      *\n");
  printf("\r * X-CUBE-WIFI1 Expansion Software V2.1.1               *\n");
  printf("\r * X-NUCLEO-IDW01M1 Wi-Fi Mini-AP Configuration.        *\n");
  printf("\r * Server-Socket Example                                *\n");
  printf("\r *                                                      *\n");
  printf("\r *******************************************************/\n");
  printf("\r\nDo you want to setup SSID?(y/n):");
  fflush(stdout);
  //  scanf("%s",console_input);
  
  //HAL_UART_Receive(&UartMsgHandle, (uint8_t *)console_input, 1, 100000);
  
  printf("\r\n\nModule will connect with default settings.");
  memcpy(console_ssid, (const char*)ssid, strlen((char*)ssid));             
  
  
  printf("\r\n/*************************************************************\r\n");
  printf("\r\n * Configuration Complete                                     \r\n");
  printf("\r\n * Please make sure a server is listening at given hostname   \r\n");
  printf("\r\n *************************************************************\r\n");
  
  return status;
}

/******** Wi-Fi Indication User Callback *********/

void ind_wifi_socket_data_received(uint8_t socket_id, uint8_t * data_ptr, uint32_t message_size, uint32_t chunk_size)
{
  printf("\r\nData Receive Callback...\r\n");
  memcpy(echo, data_ptr, 50);
  printf((const char*)echo);
  printf("\r\nsocket ID: %d\r\n",socket_id);
  printf("msg size: %lu\r\n",(unsigned long)message_size);
  printf("chunk size: %lu\r\n",(unsigned long)chunk_size);
  fflush(stdout);
  wifi_state = wifi_state_write;  
}

void ind_wifi_on()
{
  wifi_state = wifi_state_ready;
}

void ind_wifi_connected()
{
  wifi_state = wifi_state_connected;
}

void ind_socket_server_client_joined(void)
{
  printf("\r\nUser callback: Client joined...\r\n");
  fflush(stdout);
}

void ind_socket_server_client_left(void)
{
  printf("\r\nUser callback: Client left...\r\n");
  fflush(stdout);
}

void ind_wifi_ap_client_joined(uint8_t * client_mac_address)
{
  printf("\r\n>>client joined callback...\r\n");
  printf((const char*)client_mac_address);
  fflush(stdout);  
}

void ind_wifi_ap_client_left(uint8_t * client_mac_address)
{
  printf("\r\n>>client left callback...\r\n");
  printf((const char*)client_mac_address);
  fflush(stdout);  
}
#endif
//==============================================================================
//==============================================================================
// TSL_routines
//==============================================================================
//==============================================================================

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
/**
* @brief  Manage the activity on sensors when touched/released (example)
* @param  None
* @retval None
*/
void ProcessSensors(void)
{
  uint32_t idx;
  //uint32_t idxch;
  uint32_t idx_ds = 0;
  uint32_t idx_dd = 0;
  
#if TSLPRM_TOTAL_TKEYS > 0  
  // Read all TKeys
//  for (idx = 0; idx < TSLPRM_TOTAL_TKEYS; idx++)
  for (idx = 0; idx < 4; idx++)
  {
    // STMStudio debug
    DS[idx_ds++] = MyTKeys[idx].p_Data->StateId;    
    DD[idx_dd++] = MyTKeys[idx].p_ChD->Delta;
    if (DETECT_TKEY(idx) || TOUCH_TKEY(idx))
      //    if (TEST_TKEY(idx))
    {
            KeyRead |= (1<<idx);
    }
    else
    {
      KeyRead &= ~(1<<idx);    
      if(MyTKeys[idx].p_Data->StateId == TSL_STATEID_RELEASE)
      {
         if(MyTKeys[idx].p_ChD->Ref < (TouchRef[idx] - TSLPRM_TKEY_DETECT_IN_TH))
         {
            MyTKeys[idx].p_ChD->Ref = TouchRef[idx];
         }
      }
    }
  }
#endif
}

/**
* @brief  Executed when a sensor is in Error state
* @param  None
* @retval None
*/
void MyTKeys_ErrorStateProcess(void)
{
  // Add here your own processing when a sensor is in Error state
  TSL_tkey_SetStateOff();
}


/**
* @brief  Executed when a sensor is in Off state
* @param  None
* @retval None
*/
void MyTKeys_OffStateProcess(void)
{
  // Add here your own processing when a sensor is in Off state
}


/**
* @brief  Executed when a sensor is in Error state
* @param  None
* @retval None
*/
void MyLinRots_ErrorStateProcess(void)
{
  // Add here your own processing when a sensor is in Error state
}


/**
* @brief  Executed when a sensor is in Off state
* @param  None
* @retval None
*/
void MyLinRots_OffStateProcess(void)
{
  // Add here your own processing when a sensor is in Off state
}


//-------------------
// CallBack functions
//-------------------

/**
* @brief  Executed at each timer interruption (option must be enabled)
* @param  None
* @retval None
*/
void TSL_CallBack_TimerTick(void)
{
}
/* USER CODE END 4 */


#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
  ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
