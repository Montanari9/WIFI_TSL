
#include "stm32f0xx_hal.h"

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __define_H
#define __define_H

// -----------------------------------------------------------------------------
// version
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Bits variaveis
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// flag for general use
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// define flags
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// define bits
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// TSC
// -----------------------------------------------------------------------------
#define TEST_TKEY(NB)   (MyTKeys[(NB)].p_Data->StateId == TSL_STATEID_DETECT)
#define DETECT_TKEY(NB)   (MyTKeys[(NB)].p_Data->StateId == TSL_STATEID_DETECT)
#define TOUCH_TKEY(NB)   (MyTKeys[(NB)].p_Data->StateId == TSL_STATEID_TOUCH)
#define TSLPRM_TOTAL_TKEYS (TSLPRM_TOTAL_TOUCHKEYS + TSLPRM_TOTAL_TOUCHKEYS_B)
#define TSLPRM_TOTAL_LNRTS (TSLPRM_TOTAL_LINROTS + TSLPRM_TOTAL_LINROTS_B)
#define TSL_NB_GROUPS (6) // Only 6 groups on STM32F0xx

#define TSL_GROUP1 (0x01)
#define TSL_GROUP2 (0x02)
#define TSL_GROUP3 (0x04)
#define TSL_GROUP4 (0x08)
#define TSL_GROUP5 (0x10)
#define TSL_GROUP6 (0x20)



/* Private macros ------------------------------------------------------------*/
#define IS_BANK_INDEX_OK(INDEX)   (((INDEX) == 0) || (((INDEX) > 0) && ((INDEX) < TSLPRM_TOTAL_BANKS)))
#define IS_SOURCE_INDEX_OK(INDEX) (((INDEX) == 0) || (((INDEX) > 0) && ((INDEX) < TSLPRM_TOTAL_CHANNELS)))

#endif /* __define_H */
