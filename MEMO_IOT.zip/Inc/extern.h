#include "tsl.h"
//#include "stm32f0xx.h"
#include "stm32f0xx_hal.h"
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __extern_H
#define __extern_H

extern unsigned char BYPASS_DTO;
extern unsigned char ENABLE_RESET_BYPASS_DTO;

extern uint8_t DS[TSLPRM_TOTAL_TKEYS + TSLPRM_TOTAL_LNRTS]; // To store the States (one per object)
extern int16_t DD[TSLPRM_TOTAL_TKEYS + (TSLPRM_TOTAL_LNRTS * 3)]; // To store the Deltas (one per channel)
extern CONST TSL_TouchKey_T MyTKeys[TSLPRM_TOTAL_TKEYS];
extern uint16_t Delay_WIFI_Main;

extern uint16_t DelayDisplayWiFi;
extern uint16_t ComandoWiFi;

extern __IO uint32_t Gv_EOA; // Set by TS interrupt routine to indicate the End Of Acquisition

#endif /* __extern_H */